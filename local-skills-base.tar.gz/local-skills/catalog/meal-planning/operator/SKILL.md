---
name: meal-planning-operator
description: |
  Operate ongoing meal-planning workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meal Planning Operator

Use for recurring planning, shopping lists, and prep scheduling.
