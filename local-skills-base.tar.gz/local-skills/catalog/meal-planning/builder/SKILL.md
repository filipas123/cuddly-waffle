---
name: meal-planning-builder
description: |
  Build meal plans, recipe suggestions, and shopping support.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meal Planning Builder

Balance convenience, nutrition, and cost with explicit substitutions.
