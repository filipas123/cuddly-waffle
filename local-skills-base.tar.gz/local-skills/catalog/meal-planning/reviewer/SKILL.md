---
name: meal-planning-reviewer
description: |
  Review meal plans for practicality and constraint fit.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meal Planning Reviewer

Flag unrealistic prep load, budget drift, or missed dietary constraints.
