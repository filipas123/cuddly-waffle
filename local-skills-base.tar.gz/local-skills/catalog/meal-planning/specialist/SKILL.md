---
name: meal-planning-specialist
description: |
  Advanced dietary and nutrition-aware planning.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meal Planning Specialist

Use for more complex dietary, household, and cost balancing.
