---
name: meal-planning-foundation
description: |
  Base principles for practical meal and recipe planning.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meal Planning Foundation

Start from constraints: budget, ingredients, nutrition, time, and dietary needs.
