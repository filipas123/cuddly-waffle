---
name: travel-planning-specialist
description: |
  Advanced itinerary and logistics design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Travel Planning Specialist

Use for multi-stop trips, preference-heavy planning, and schedule-risk management.
