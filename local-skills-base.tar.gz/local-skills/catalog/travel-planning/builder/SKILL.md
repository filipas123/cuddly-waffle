---
name: travel-planning-builder
description: |
  Build itineraries, travel options, and trip plans.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Travel Planning Builder

Balance time, cost, convenience, and user preferences with explicit assumptions.
