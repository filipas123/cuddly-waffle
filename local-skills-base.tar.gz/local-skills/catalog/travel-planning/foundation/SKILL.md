---
name: travel-planning-foundation
description: |
  Foundational travel planning principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Travel Planning Foundation

Start with constraints: destination, dates, budget, preferences, and logistical limits.
