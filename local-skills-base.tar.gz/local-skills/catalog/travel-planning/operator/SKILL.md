---
name: travel-planning-operator
description: |
  Operate travel-planning workflows and updates.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Travel Planning Operator

Use for itinerary revisions, day plans, and logistics coordination.
