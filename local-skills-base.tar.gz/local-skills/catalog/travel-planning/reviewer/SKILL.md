---
name: travel-planning-reviewer
description: |
  Review travel plans for practicality and constraint fit.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Travel Planning Reviewer

Flag unrealistic transfers, budget mismatch, and missing contingency planning.
