---
name: customer-support-operator
description: |
  Operate support interactions in live workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Customer Support Operator

Handle triage, follow-up, customer history, and escalation discipline.
