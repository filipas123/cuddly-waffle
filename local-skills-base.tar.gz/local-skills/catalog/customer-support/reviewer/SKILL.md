---
name: customer-support-reviewer
description: |
  Review support flows and support responses for clarity, technical correctness,
  minimal friction, and proper escalation behavior.
license: MIT
metadata:
  author: local
  version: "1.1.0"
---

# Customer Support Reviewer

Review whether support behavior actually helps the user move forward.

## Findings to Look For

- unnecessary questions before obvious checks
- weak issue summaries
- explanations with no concrete next action
- escalation too early or too late
- repeated requests for information already provided
