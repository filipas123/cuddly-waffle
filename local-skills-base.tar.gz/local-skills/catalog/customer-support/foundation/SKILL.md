---
name: customer-support-foundation
description: |
  Base support principles for issue handling and communication.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Customer Support Foundation

Clarify the issue, user impact, and minimal next step.
