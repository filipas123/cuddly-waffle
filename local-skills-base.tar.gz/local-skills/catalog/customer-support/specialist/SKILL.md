---
name: customer-support-specialist
description: |
  Advanced customer support strategy for complex technical products.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Customer Support Specialist

Use for high-context cases, recurring incidents, and support-system design.
