---
name: data-engineering-operator
description: |
  Operate data pipelines and monitor freshness, failures, and drift.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Data Engineering Operator

Use for job failures, quality alerts, and pipeline reliability.
