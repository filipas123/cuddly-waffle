---
name: data-engineering-foundation
description: |
  Foundational data engineering principles for pipelines, transformations, quality, and lineage.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Data Engineering Foundation

Start from source reliability, schema shape, freshness, ownership, and downstream use.
