---
name: data-engineering-builder
description: |
  Build data pipelines, transformation workflows, and quality-aware data flows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Data Engineering Builder

Define ingestion, normalization, validation, storage, and observability.
