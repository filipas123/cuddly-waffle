---
name: data-engineering-specialist
description: |
  Advanced data engineering for large pipelines, lineage, quality enforcement, and model-feeding data systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Data Engineering Specialist

Use for complex ETL/ELT, analytics backbones, and AI training or RAG data preparation.
