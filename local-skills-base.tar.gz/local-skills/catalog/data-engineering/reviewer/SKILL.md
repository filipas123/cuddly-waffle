---
name: data-engineering-reviewer
description: |
  Review data systems for quality risk, schema drift, lineage gaps, and operational fragility.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Data Engineering Reviewer

Flag hidden assumptions, weak validation, and missing failure handling.
