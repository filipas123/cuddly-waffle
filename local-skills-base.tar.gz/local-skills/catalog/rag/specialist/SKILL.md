---
name: rag-specialist
description: |
  Advanced retrieval system design for agentic, corrective, and reasoning-heavy RAG.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# RAG Specialist

Use for hard RAG problems involving routing, hybrid search, iterative retrieval, and complex evidence synthesis.
