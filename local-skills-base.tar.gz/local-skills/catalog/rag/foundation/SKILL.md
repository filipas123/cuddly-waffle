---
name: rag-foundation
description: |
  Foundational retrieval-augmented generation design and grounding rules.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# RAG Foundation

Use this skill to frame document-grounded systems. Focus on ingestion, chunking, retrieval boundaries, source quality, and grounding expectations.
