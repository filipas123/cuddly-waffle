---
name: rag-operator
description: |
  Operate and debug retrieval-backed systems in active use.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# RAG Operator

Focus on document freshness, index health, query failures, slow retrieval, and bad result quality.
