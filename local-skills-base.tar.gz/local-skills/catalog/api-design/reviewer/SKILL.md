---
name: api-design-reviewer
description: |
  Review APIs for contract clarity, breaking-change risk, weak semantics, and operational blind spots.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# API Design Reviewer

Check consumer usability, consistency, and long-term evolution risk.
