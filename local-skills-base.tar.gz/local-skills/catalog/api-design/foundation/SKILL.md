---
name: api-design-foundation
description: |
  Foundational API design principles for clear contracts, evolvability, and operational fit.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# API Design Foundation

Define resources, operations, consumers, error semantics, and versioning strategy early.
