---
name: api-design-operator
description: |
  Operate APIs through change management, deprecation, and production feedback.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# API Design Operator

Use for version rollout, contract drift, and integration incident analysis.
