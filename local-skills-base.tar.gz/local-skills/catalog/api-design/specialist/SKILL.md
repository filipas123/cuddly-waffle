---
name: api-design-specialist
description: |
  Advanced API design for platform surfaces, complex integrations, and long-lived contracts.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# API Design Specialist

Use for high-scale APIs, platform ecosystems, and difficult compatibility constraints.
