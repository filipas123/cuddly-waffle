---
name: backend-service-design-foundation
description: |
  Foundational principles for backend service design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Backend Service Design Foundation

Define service boundary, ownership, data responsibilities, and failure behavior.
