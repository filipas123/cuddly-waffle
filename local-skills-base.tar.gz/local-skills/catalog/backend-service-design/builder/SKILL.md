---
name: backend-service-design-builder
description: |
  Build backend services with explicit interfaces, state handling, and operational expectations.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Backend Service Design Builder

Design endpoints, jobs, storage, retries, and service-to-service behavior.
