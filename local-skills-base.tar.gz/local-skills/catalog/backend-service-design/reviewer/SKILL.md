---
name: backend-service-design-reviewer
description: |
  Review backend services for contract weakness, failure handling gaps, and scaling risk.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Backend Service Design Reviewer

Look for hidden coupling, bad retry logic, and ambiguous ownership.
