---
name: backend-service-design-specialist
description: |
  Advanced backend service architecture and runtime tradeoff design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Backend Service Design Specialist

Use for distributed service ecosystems and reliability-critical backend systems.
