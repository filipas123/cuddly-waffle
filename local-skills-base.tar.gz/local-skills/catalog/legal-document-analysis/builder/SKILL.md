---
name: legal-document-analysis-builder
description: |
  Build workflows for clause analysis, issue spotting, document comparison, and structured summarization.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Legal Document Analysis Builder

Highlight obligations, risks, missing terms, and ambiguities without overstating conclusions.
