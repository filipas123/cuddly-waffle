---
name: legal-document-analysis-specialist
description: |
  Advanced contract and document issue-spotting support within non-lawyer system boundaries.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Legal Document Analysis Specialist

Use for high-structure review support, not final legal advice.
