---
name: legal-document-analysis-operator
description: |
  Operate document review workflows and iteration cycles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Legal Document Analysis Operator

Use for repeated analysis, comparison, and red-flag extraction.
