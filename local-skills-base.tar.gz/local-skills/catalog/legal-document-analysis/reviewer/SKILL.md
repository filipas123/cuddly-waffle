---
name: legal-document-analysis-reviewer
description: |
  Review document analysis outputs for missing clauses, weak issue framing, and overstatement.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Legal Document Analysis Reviewer

Flag unsupported interpretations and ambiguous summaries.
