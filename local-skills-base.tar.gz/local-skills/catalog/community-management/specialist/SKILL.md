---
name: community-management-specialist
description: |
  Advanced community operations and engagement design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Community Management Specialist

Use for high-volume or sensitive communities where trust and moderation quality matter.
