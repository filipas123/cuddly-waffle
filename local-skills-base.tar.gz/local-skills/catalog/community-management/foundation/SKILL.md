---
name: community-management-foundation
description: |
  Foundational community management principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Community Management Foundation

Define audience norms, participation model, moderation posture, and trust expectations.
