---
name: community-management-builder
description: |
  Build community communications, moderation workflows, and engagement structures.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Community Management Builder

Use for discussion design, response patterns, and community operations.
