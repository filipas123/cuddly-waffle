---
name: community-management-operator
description: |
  Operate community-facing workflows and moderation cycles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Community Management Operator

Use for announcements, response handling, and moderation support.
