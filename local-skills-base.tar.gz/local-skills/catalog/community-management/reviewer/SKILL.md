---
name: community-management-reviewer
description: |
  Review community workflows for tone mismatch, moderation gaps, and unhealthy engagement incentives.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Community Management Reviewer

Flag policies or patterns that scale poorly or damage trust.
