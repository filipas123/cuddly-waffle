---
name: memory-specialist
description: |
  Advanced memory design for long-lived AI products.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Memory Specialist

Use for scoped retention, preference memory, memory audits, and memory/retrieval separation.
