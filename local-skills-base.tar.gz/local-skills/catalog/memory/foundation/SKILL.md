---
name: memory-foundation
description: |
  Foundational memory design for AI systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Memory Foundation

Define scope, retention, privacy, retrieval behavior, and what should not persist.
