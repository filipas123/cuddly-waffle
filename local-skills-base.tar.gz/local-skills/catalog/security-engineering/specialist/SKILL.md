---
name: security-engineering-specialist
description: |
  Advanced security engineering for vulnerability analysis, adversarial testing, sandboxing, and control design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Security Engineering Specialist

Use for cybersecurity testing, vulnerability detection, exploitability analysis, and high-risk system review.
