---
name: security-engineering-builder
description: |
  Build secure systems, controls, and assessment workflows for software and AI environments.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Security Engineering Builder

Cover auth, secrets handling, input validation, execution boundaries, network exposure, logging, and least privilege.
