---
name: security-engineering-reviewer
description: |
  Review code and systems for exploitable weakness, bad assumptions, and weak control boundaries.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Security Engineering Reviewer

Prioritize findings by exploitability and impact, not by checklist theatrics.
