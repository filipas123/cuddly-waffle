---
name: security-engineering-operator
description: |
  Operate security-sensitive systems and testing workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Security Engineering Operator

Use for triage, hardening checks, monitoring gaps, and exposure review.
