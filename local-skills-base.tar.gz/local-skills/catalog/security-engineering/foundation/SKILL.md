---
name: security-engineering-foundation
description: |
  Foundational security engineering principles for software, AI systems, and automated workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Security Engineering Foundation

Start from assets, trust boundaries, attacker paths, and the difference between prevention, detection, and response.
