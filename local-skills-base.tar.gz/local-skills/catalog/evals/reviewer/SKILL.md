---
name: evals-reviewer
description: |
  Review whether an eval harness actually measures what matters.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Evals Reviewer

Look for biased samples, vague rubrics, and tests that miss known failures.
