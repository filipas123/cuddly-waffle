---
name: evals-foundation
description: |
  Foundational evaluation design for AI systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Evals Foundation

Define task classes, expected behavior, and measurable quality criteria before changing models or prompts.
