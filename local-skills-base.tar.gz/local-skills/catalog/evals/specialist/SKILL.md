---
name: evals-specialist
description: |
  Advanced evaluation design for complex model-backed systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Evals Specialist

Use for nuanced scoring, workflow evaluation, and diagnostic failure taxonomy.
