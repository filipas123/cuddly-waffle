---
name: product-management-reviewer
description: |
  Review product plans for weak problem framing, ungrounded prioritization, and unclear success criteria.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Product Management Reviewer

Flag feature thinking without outcome thinking.
