---
name: product-management-builder
description: |
  Build product requirements, roadmaps, prioritization frames, and delivery plans.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Product Management Builder

Translate user needs into scoped work with explicit tradeoffs.
