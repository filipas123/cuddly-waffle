---
name: product-management-foundation
description: |
  Foundational product management principles for goals, user problems, and delivery tradeoffs.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Product Management Foundation

Define user need, product outcome, constraints, and success metrics before solution detail.
