---
name: product-management-operator
description: |
  Operate product workflows across planning, execution, and feedback cycles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Product Management Operator

Use for backlog shaping, release framing, and iteration based on evidence.
