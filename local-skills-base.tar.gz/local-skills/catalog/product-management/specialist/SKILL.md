---
name: product-management-specialist
description: |
  Advanced product strategy and delivery design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Product Management Specialist

Use for roadmap arbitration, platform tradeoffs, and ambiguous product spaces.
