---
name: technical-writing-specialist
description: |
  Advanced documentation design for complex technical systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Technical Writing Specialist

Use for architecture docs, SDK docs, onboarding systems, and multi-audience content.
