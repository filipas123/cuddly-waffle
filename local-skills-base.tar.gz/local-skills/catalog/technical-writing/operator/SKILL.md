---
name: technical-writing-operator
description: |
  Operate documentation workflows and keep docs in sync with systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Technical Writing Operator

Use for README updates, release notes, and maintenance documentation.
