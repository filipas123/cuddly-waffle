---
name: technical-writing-foundation
description: |
  Base principles for clear technical communication.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Technical Writing Foundation

Lead with user goal, structure for scanning, and show concrete examples.
