---
name: system-architecture-foundation
description: |
  Base principles for architecture analysis and design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# System Architecture Foundation

Start from requirements, constraints, scale, security, and operational needs.
