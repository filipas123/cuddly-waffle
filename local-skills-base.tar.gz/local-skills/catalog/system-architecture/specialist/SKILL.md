---
name: system-architecture-specialist
description: |
  Advanced architecture analysis for high-scale or high-risk systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# System Architecture Specialist

Use for complex tradeoffs across scale, compliance, resilience, and cost.
