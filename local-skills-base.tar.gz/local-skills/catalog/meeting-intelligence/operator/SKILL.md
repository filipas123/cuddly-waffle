---
name: meeting-intelligence-operator
description: |
  Operate meeting workflows before and after meetings.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meeting Intelligence Operator

Use for prep packets, summaries, and action tracking.
