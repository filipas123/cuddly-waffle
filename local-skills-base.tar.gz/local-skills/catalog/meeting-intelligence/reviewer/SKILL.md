---
name: meeting-intelligence-reviewer
description: |
  Review meeting prep for missing context or poor prioritization.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meeting Intelligence Reviewer

Flag weak objectives, missing stakeholders, and unfocused talking points.
