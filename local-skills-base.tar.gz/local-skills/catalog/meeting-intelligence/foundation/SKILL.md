---
name: meeting-intelligence-foundation
description: |
  Base principles for meeting preparation and briefing.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meeting Intelligence Foundation

Define objective, participants, risks, and what success looks like.
