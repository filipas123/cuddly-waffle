---
name: meeting-intelligence-specialist
description: |
  Advanced executive briefing and high-stakes meeting support.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Meeting Intelligence Specialist

Use for negotiation prep, board-style summaries, and sensitive stakeholder mapping.
