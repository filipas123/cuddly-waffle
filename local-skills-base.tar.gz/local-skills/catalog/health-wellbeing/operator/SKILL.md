---
name: health-wellbeing-operator
description: |
  Operate wellness-oriented support workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Health Wellbeing Operator

Use for recurring plans, progress prompts, and routine management with clear non-clinical boundaries.
