---
name: health-wellbeing-specialist
description: |
  Advanced health-content structuring within safe informational boundaries.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Health Wellbeing Specialist

Use for high-structure wellness planning and educational synthesis, not diagnosis.
