---
name: health-wellbeing-foundation
description: |
  Foundational principles for non-diagnostic health and wellbeing support content.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Health Wellbeing Foundation

Stay within informational and planning support, not clinical diagnosis or treatment claims.
