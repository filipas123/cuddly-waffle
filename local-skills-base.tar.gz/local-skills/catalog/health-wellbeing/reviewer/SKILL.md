---
name: health-wellbeing-reviewer
description: |
  Review wellbeing content for scope, clarity, and unsafe overclaiming.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Health Wellbeing Reviewer

Flag diagnostic language, unsafe certainty, and missing caution where needed.
