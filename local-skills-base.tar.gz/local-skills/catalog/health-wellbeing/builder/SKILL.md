---
name: health-wellbeing-builder
description: |
  Build health, wellness, and habit-support content with careful scope control.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Health Wellbeing Builder

Use for routines, planning, educational content, and structured wellbeing support while avoiding overreach.
