---
name: multi-agent-foundation
description: |
  Base principles for role separation, delegation, and handoffs.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multi-Agent Foundation

Use only when task decomposition adds real value. Keep roles bounded and context small.
