---
name: multi-agent-builder
description: |
  Build multi-agent workflows with clear role contracts and validation.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multi-Agent Builder

Define role responsibilities, handoff artifacts, and final synthesis checks.
