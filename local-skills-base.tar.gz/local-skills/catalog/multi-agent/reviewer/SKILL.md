---
name: multi-agent-reviewer
description: |
  Review multi-agent systems for duplicated work, context blowup, and weak coordination.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multi-Agent Reviewer

Look for circular delegation, fuzzy roles, and missing validation between stages.
