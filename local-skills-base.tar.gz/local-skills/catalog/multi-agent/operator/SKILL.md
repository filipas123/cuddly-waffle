---
name: multi-agent-operator
description: |
  Operate delegated workflows and supervise handoffs and task completion.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multi-Agent Operator

Track progress, intervene on blocked subtasks, and collapse to simpler flows when overhead dominates.
