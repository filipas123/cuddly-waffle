---
name: frontend-design-system-builder
description: |
  Build component systems, interaction patterns, and frontend conventions.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Frontend Design System Builder

Create reusable UI contracts, visual consistency, and implementation guidance.
