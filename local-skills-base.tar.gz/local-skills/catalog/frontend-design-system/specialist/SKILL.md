---
name: frontend-design-system-specialist
description: |
  Advanced frontend system design for scalable product interfaces.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Frontend Design System Specialist

Use for mature component systems, token strategies, and cross-product consistency.
