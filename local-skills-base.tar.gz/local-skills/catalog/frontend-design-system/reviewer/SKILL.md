---
name: frontend-design-system-reviewer
description: |
  Review design systems for inconsistency, poor accessibility, and weak component boundaries.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Frontend Design System Reviewer

Flag visual drift, duplicated primitives, and missing usage guidance.
