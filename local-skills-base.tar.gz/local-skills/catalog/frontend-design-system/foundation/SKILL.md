---
name: frontend-design-system-foundation
description: |
  Foundational principles for UI systems, consistency, and reusable frontend building blocks.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Frontend Design System Foundation

Define design primitives, interaction expectations, and accessibility baseline.
