---
name: frontend-design-system-operator
description: |
  Operate and evolve a frontend design system over time.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Frontend Design System Operator

Use for component adoption, version drift, and pattern governance.
