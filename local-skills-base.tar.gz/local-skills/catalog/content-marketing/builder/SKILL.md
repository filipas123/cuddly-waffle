---
name: content-marketing-builder
description: |
  Build content plans, articles, campaign assets, and editorial structures.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Content Marketing Builder

Tie content to audience need and business outcome.
