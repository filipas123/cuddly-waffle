---
name: content-marketing-foundation
description: |
  Foundational content marketing principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Content Marketing Foundation

Define audience, objective, channel, and conversion path before creating content.
