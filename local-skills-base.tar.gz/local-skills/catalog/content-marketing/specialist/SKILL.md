---
name: content-marketing-specialist
description: |
  Advanced content strategy and campaign design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Content Marketing Specialist

Use for integrated content systems and multi-channel messaging.
