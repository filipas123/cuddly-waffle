---
name: content-marketing-operator
description: |
  Operate content workflows across planning, publishing, and iteration.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Content Marketing Operator

Use for editorial pipeline management and performance-driven content adjustment.
