---
name: startup-analysis-foundation
description: |
  Foundational startup and product analysis principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Startup Analysis Foundation

Frame market, problem, user, competition, and execution constraints clearly.
