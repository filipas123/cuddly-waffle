---
name: startup-analysis-operator
description: |
  Operate startup research and update workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Startup Analysis Operator

Use for ongoing market tracking, opportunity refinement, and strategy iteration.
