---
name: startup-analysis-reviewer
description: |
  Review startup analysis for unsupported market claims and weak strategic reasoning.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Startup Analysis Reviewer

Flag hand-wavy TAM logic, weak differentiation, and hidden execution risks.
