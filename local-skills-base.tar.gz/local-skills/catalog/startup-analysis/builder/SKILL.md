---
name: startup-analysis-builder
description: |
  Build startup analyses, market scans, and product positioning briefs.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Startup Analysis Builder

Evaluate market need, competitive alternatives, risks, and execution path.
