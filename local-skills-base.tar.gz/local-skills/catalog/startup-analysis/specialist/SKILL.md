---
name: startup-analysis-specialist
description: |
  Advanced startup and product strategy analysis.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Startup Analysis Specialist

Use for investment-style opportunity review, GTM reasoning, and strategic positioning.
