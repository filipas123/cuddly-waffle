---
name: software-development-foundation
description: |
  Base software engineering principles for implementation work.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Software Development Foundation

Use clear interfaces, correctness first, explicit assumptions, and testable changes.
