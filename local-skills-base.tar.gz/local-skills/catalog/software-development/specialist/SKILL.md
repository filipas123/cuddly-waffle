---
name: software-development-specialist
description: |
  Advanced software engineering specialization across languages and stacks.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Software Development Specialist

Use for deeper implementation and review work where general guidance is insufficient.
