---
name: software-development-operator
description: |
  Operate development workflows across build, debug, and iteration loops.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Software Development Operator

Use for ongoing coding tasks, issue diagnosis, and integration work.
