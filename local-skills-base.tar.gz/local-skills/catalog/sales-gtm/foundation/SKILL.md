---
name: sales-gtm-foundation
description: |
  Foundational sales and go-to-market principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Sales GTM Foundation

Define buyer, problem, offer, channel, and success metric before tactics.
