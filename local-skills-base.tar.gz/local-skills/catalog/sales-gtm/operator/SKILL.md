---
name: sales-gtm-operator
description: |
  Operate go-to-market workflows and campaign updates.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Sales GTM Operator

Use for iteration on messaging, outreach structure, and sales enablement outputs.
