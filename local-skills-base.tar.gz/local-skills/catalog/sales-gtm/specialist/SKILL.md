---
name: sales-gtm-specialist
description: |
  Advanced GTM and sales strategy analysis.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Sales GTM Specialist

Use for launch strategy, channel tradeoffs, and positioning under competition.
