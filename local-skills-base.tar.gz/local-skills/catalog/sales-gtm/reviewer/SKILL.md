---
name: sales-gtm-reviewer
description: |
  Review GTM plans for vague positioning, weak segmentation, and unsupported funnel assumptions.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Sales GTM Reviewer

Flag activity without strategic coherence.
