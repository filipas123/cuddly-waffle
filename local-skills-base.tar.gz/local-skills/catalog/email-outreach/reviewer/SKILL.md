---
name: email-outreach-reviewer
description: |
  Review outreach emails for noise, weak personalization, and unclear call to action.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Email Outreach Reviewer

Flag fluff, generic messaging, and multi-ask confusion.
