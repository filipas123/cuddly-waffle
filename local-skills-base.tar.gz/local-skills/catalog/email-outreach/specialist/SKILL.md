---
name: email-outreach-specialist
description: |
  Advanced outreach design for high-value communication workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Email Outreach Specialist

Use for nuanced personalization and strategy-sensitive outbound communication.
