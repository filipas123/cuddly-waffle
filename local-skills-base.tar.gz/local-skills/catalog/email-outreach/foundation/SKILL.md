---
name: email-outreach-foundation
description: |
  Foundational principles for concise, high-signal email outreach.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Email Outreach Foundation

Start with recipient context, objective, and why the message should exist at all.
