---
name: email-outreach-builder
description: |
  Build outreach sequences and individual emails for sales, recruiting, or professional communication.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Email Outreach Builder

Optimize for clarity, relevance, and a single clear ask.
