---
name: email-outreach-operator
description: |
  Operate outreach workflows and sequence iteration.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Email Outreach Operator

Use for campaign refinement, follow-up logic, and response-aware adjustments.
