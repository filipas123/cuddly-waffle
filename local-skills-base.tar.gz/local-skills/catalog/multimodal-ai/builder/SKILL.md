---
name: multimodal-ai-builder
description: |
  Build multimodal systems that combine visual, textual, and audio inputs coherently.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multimodal AI Builder

Make modality boundaries explicit, align outputs to evidence, and handle unsupported modality combinations clearly.
