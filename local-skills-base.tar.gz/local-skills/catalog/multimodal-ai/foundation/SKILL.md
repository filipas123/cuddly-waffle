---
name: multimodal-ai-foundation
description: |
  Foundational principles for systems that combine text, image, audio, or video understanding.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multimodal AI Foundation

Define modalities in scope, how they interact, and what evidence from each modality should drive output.
