---
name: multimodal-ai-reviewer
description: |
  Review multimodal systems for grounding, ambiguity handling, and cross-modal consistency.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multimodal AI Reviewer

Check whether conclusions are supported by the right modality and whether outputs overclaim beyond available evidence.
