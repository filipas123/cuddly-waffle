---
name: multimodal-ai-specialist
description: |
  Advanced multimodal system design and reasoning.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Multimodal AI Specialist

Use for image-text workflows, video understanding, cross-modal retrieval, and high-context content synthesis.
