---
name: education-research-reviewer
description: |
  Review educational and research content for rigor, clarity, and source integrity.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Education Research Reviewer

Flag shallow summaries, unsupported claims, and material that mismatches audience level.
