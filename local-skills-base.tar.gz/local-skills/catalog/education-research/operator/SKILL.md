---
name: education-research-operator
description: |
  Operate educational and research workflows over time.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Education Research Operator

Use for iterative literature review, syllabus refinement, and study-plan updates.
