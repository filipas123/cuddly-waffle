---
name: education-research-foundation
description: |
  Foundational principles for educational and research support content.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Education Research Foundation

Clarify the learning or research goal, audience level, and required rigor.
