---
name: education-research-specialist
description: |
  Advanced educational design and research synthesis.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Education Research Specialist

Use for structured learning systems, literature mapping, and academic-style synthesis.
