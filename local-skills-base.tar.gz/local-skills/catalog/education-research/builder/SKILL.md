---
name: education-research-builder
description: |
  Build learning guides, study plans, literature summaries, and research support artifacts.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Education Research Builder

Structure content progressively, cite sources when needed, and make the output usable for learning or research action.
