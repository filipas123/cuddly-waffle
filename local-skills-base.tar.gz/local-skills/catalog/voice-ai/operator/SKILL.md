---
name: voice-ai-operator
description: |
  Operate voice AI systems in live conditions.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Voice AI Operator

Monitor audio failures, timing issues, recognition errors, and degraded conversational flow.
