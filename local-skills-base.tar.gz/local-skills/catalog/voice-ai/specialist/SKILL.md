---
name: voice-ai-specialist
description: |
  Advanced voice AI design for real-time spoken interaction systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Voice AI Specialist

Use for multimodal spoken agents, call flows, and low-latency voice orchestration.
