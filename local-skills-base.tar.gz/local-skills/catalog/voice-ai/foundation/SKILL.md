---
name: voice-ai-foundation
description: |
  Foundational principles for voice-driven AI systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Voice AI Foundation

Define speech input, transcription, turn-taking, latency expectations, and audio output boundaries.
