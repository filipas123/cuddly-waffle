---
name: voice-ai-reviewer
description: |
  Review voice interfaces for latency, comprehension, dialogue pacing, and failure recovery.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Voice AI Reviewer

Check barge-in handling, transcription error recovery, and spoken-response usability.
