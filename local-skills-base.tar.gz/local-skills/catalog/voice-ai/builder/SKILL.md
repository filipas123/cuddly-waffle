---
name: voice-ai-builder
description: |
  Build voice-first AI interactions with transcription, response timing, and spoken output design.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Voice AI Builder

Optimize for interruption handling, low latency, audio clarity, and recovery from speech recognition errors.
