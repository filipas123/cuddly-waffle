---
name: compliance-risk-builder
description: |
  Build compliance-aware workflows, controls, and documentation structures.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Compliance Risk Builder

Map obligations to process, control, evidence, and review cadence.
