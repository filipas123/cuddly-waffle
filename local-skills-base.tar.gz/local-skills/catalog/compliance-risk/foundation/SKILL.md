---
name: compliance-risk-foundation
description: |
  Foundational compliance and operational risk principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Compliance Risk Foundation

Define the regulated surface, relevant obligations, and risk-bearing actions first.
