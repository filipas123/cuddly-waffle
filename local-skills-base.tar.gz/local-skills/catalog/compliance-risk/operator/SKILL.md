---
name: compliance-risk-operator
description: |
  Operate compliance-sensitive processes and control evidence.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Compliance Risk Operator

Use for policy execution, review cycles, and incident-triggered reassessment.
