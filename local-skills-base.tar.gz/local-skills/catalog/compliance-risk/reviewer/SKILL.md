---
name: compliance-risk-reviewer
description: |
  Review systems and workflows for compliance gaps and weak controls.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Compliance Risk Reviewer

Flag unsupported claims of compliance, weak evidence trails, and missing accountability.
