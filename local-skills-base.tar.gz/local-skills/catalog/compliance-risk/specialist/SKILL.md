---
name: compliance-risk-specialist
description: |
  Advanced compliance and risk framing for sensitive operational environments.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Compliance Risk Specialist

Use for regulated workflows, audit-facing artifacts, and control design.
