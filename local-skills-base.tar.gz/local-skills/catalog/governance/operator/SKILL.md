---
name: governance-operator
description: |
  Operate governed AI systems with approvals, logging, and incident awareness.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Governance Operator

Watch for policy drift, repeated denials, unsafe overrides, and audit blind spots.
