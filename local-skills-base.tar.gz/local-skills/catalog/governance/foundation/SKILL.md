---
name: governance-foundation
description: |
  Base principles for AI governance, policy, and least privilege.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Governance Foundation

Define protected assets, allowed actions, approval gates, and audit requirements.
