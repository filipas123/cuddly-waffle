---
name: testing-strategy-specialist
description: |
  Advanced test architecture across software, infrastructure, and AI behavior.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Testing Strategy Specialist

Use for high-risk systems, cross-layer testing, and reliability-critical workflows.
