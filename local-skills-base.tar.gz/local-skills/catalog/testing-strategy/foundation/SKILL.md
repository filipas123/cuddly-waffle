---
name: testing-strategy-foundation
description: |
  Foundational testing principles for application and AI systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Testing Strategy Foundation

Define what matters to test, where risk concentrates, and what confidence level is required.
