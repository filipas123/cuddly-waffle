---
name: testing-strategy-builder
description: |
  Build layered test strategies across unit, integration, end-to-end, and evaluation flows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Testing Strategy Builder

Match test type to risk, cost, and feedback speed.
