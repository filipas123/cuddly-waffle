---
name: testing-strategy-reviewer
description: |
  Review testing strategy for blind spots, over-testing, under-testing, and false confidence.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Testing Strategy Reviewer

Check whether the tests actually protect important behavior.
