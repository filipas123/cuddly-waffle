---
name: testing-strategy-operator
description: |
  Operate test suites and regression workflows in active development.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Testing Strategy Operator

Use for flaky tests, signal-to-noise problems, and release gating.
