---
name: mcp-orchestration-foundation
description: |
  Core principles for tool and capability orchestration across services.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# MCP Orchestration Foundation

Start from user goal, map required systems, constrain side effects, and keep tool selection explicit.
