---
name: mcp-orchestration-operator
description: |
  Operate multi-tool workflows with focus on failures, retries, and auditability.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# MCP Orchestration Operator

Watch for auth expiry, partial completion, service mismatches, and inconsistent outputs between steps.
