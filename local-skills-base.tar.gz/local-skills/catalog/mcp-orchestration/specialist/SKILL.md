---
name: mcp-orchestration-specialist
description: |
  Advanced orchestration for tool routing, chained workflows, and cross-system automation.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# MCP Orchestration Specialist

Use when workflows span several services and need disciplined sequencing and observability.
