---
name: prompt-engineering-operator
description: |
  Operate prompt-based systems through iteration, diagnostics, and controlled rollout.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Prompt Engineering Operator

Track regressions, prompt drift, and failure patterns across task classes.
