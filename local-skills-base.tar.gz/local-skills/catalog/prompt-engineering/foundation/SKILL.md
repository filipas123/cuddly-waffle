---
name: prompt-engineering-foundation
description: |
  Foundational prompt design principles for reliable model behavior.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Prompt Engineering Foundation

Define task, role, output contract, failure conditions, and trust boundaries explicitly.
