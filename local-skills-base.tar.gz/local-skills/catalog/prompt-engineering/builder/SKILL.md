---
name: prompt-engineering-builder
description: |
  Build prompts, prompt systems, and instruction stacks for AI tasks.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Prompt Engineering Builder

Use explicit task framing, schema constraints, few-shot examples only when justified, and clear refusal or fallback behavior.
