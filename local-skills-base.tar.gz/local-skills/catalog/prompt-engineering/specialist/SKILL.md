---
name: prompt-engineering-specialist
description: |
  Advanced prompt and instruction architecture for tool use, structured output, agent roles, and adversarial robustness.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Prompt Engineering Specialist

Use for complex instruction hierarchies, chained prompts, and resilient prompt systems.
