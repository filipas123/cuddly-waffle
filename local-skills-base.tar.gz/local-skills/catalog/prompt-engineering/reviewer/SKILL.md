---
name: prompt-engineering-reviewer
description: |
  Review prompt systems for ambiguity, brittleness, injection exposure, and poor behavioral control.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Prompt Engineering Reviewer

Check whether the prompt actually governs behavior or merely sounds sophisticated.
