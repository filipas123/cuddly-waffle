---
name: web-extraction-specialist
description: |
  Advanced web content extraction and browser-driven capture.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Web Extraction Specialist

Use for dynamic sites, structured extraction, and high-fidelity research collection.
