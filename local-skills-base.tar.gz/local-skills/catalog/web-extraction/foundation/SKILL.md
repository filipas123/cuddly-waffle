---
name: web-extraction-foundation
description: |
  Foundational principles for extracting content from websites and web sources.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Web Extraction Foundation

Define what content matters, trust boundaries, and whether static fetch or browser execution is required.
