---
name: web-extraction-reviewer
description: |
  Review web extraction workflows for completeness, fidelity, and brittle selectors or assumptions.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Web Extraction Reviewer

Flag missing content, JS-rendering blind spots, and extraction that loses important context.
