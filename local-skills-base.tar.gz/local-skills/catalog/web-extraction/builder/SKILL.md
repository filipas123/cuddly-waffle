---
name: web-extraction-builder
description: |
  Build web extraction workflows for content retrieval, summarization, and structured capture.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Web Extraction Builder

Choose the right extraction path, normalize results, and preserve source context.
