---
name: web-extraction-operator
description: |
  Operate web extraction workflows and monitor content drift.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Web Extraction Operator

Use for repeated capture jobs, changing site structure, and extraction-quality monitoring.
