---
name: journalism-builder
description: |
  Build reported summaries, explainers, and evidence-backed narratives.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Journalism Builder

Use multiple sources, preserve factual grounding, and separate confirmed facts from interpretation.
