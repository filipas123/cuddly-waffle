---
name: journalism-operator
description: |
  Operate reporting workflows and update cycles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Journalism Operator

Track new facts, source changes, and corrections or revisions over time.
