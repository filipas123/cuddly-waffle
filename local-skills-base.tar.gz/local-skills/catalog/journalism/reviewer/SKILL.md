---
name: journalism-reviewer
description: |
  Review reporting for sourcing strength, fairness, and unsupported framing.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Journalism Reviewer

Flag weak attribution, hidden assumptions, and narrative claims that exceed evidence.
