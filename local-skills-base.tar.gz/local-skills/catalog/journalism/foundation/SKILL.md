---
name: journalism-foundation
description: |
  Foundational reporting and synthesis principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Journalism Foundation

Distinguish reporting from commentary, verify facts, and preserve attribution.
