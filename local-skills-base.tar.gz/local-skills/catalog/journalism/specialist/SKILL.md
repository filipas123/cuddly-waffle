---
name: journalism-specialist
description: |
  Advanced reporting and narrative synthesis for complex topics.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Journalism Specialist

Use for investigations, explainers, and high-context reporting tasks.
