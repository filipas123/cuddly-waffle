---
name: devops-operations-operator
description: |
  Operate services, deploy safely, and respond to runtime incidents.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# DevOps Operations Operator

Use for release work, reliability issues, environment drift, and incident handling.
