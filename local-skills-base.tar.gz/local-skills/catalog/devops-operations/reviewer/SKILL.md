---
name: devops-operations-reviewer
description: |
  Review operational design for fragility, unsafe deployment paths, and missing observability.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# DevOps Operations Reviewer

Flag brittle pipelines, unclear rollback, and hidden config risk.
