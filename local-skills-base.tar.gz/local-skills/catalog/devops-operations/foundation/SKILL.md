---
name: devops-operations-foundation
description: |
  Foundational DevOps and operations principles for deployment, reliability, and service ownership.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# DevOps Operations Foundation

Define environments, release flow, observability, rollback, and operational responsibilities.
