---
name: devops-operations-builder
description: |
  Build deployment, CI/CD, configuration, and service operation workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# DevOps Operations Builder

Cover build pipelines, environment promotion, config management, secrets, and incident readiness.
