---
name: finance-foundation
description: |
  Base financial analysis and planning principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Finance Foundation

Separate facts from interpretation and define time horizon and assumptions.
