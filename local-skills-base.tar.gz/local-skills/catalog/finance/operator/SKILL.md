---
name: finance-operator
description: |
  Operate finance research and planning workflows.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Finance Operator

Track input freshness, source quality, and decision-relevant output.
