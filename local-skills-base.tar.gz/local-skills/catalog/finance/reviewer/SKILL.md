---
name: finance-reviewer
description: |
  Review financial analysis for unsupported conclusions, weak assumptions,
  inconsistent comparison frames, and hidden downside risk.
license: MIT
metadata:
  author: local
  version: "1.1.0"
---

# Finance Reviewer

Review whether the analysis is decision-useful rather than merely fluent.

## Review Questions

- are assumptions explicit?
- are comparisons made on the same basis?
- is downside risk addressed?
- does the conclusion exceed the available evidence?
- are time horizon and uncertainty handled honestly?
