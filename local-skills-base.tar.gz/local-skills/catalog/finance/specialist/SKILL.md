---
name: finance-specialist
description: |
  Advanced financial analysis and advisory structuring.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Finance Specialist

Use for company comparison, portfolio reasoning, and planning under uncertainty.
