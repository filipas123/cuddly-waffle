---
name: optimization-foundation
description: |
  Foundational optimization thinking for AI systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Optimization Foundation

Identify the real bottleneck before optimizing: prompt size, retrieval noise, model choice, orchestration, or UI latency.
