---
name: optimization-reviewer
description: |
  Review optimization changes for regressions and hidden tradeoffs.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Optimization Reviewer

Check that reduced cost or latency did not quietly degrade quality or reliability.
