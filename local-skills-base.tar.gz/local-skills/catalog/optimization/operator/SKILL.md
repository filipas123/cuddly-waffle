---
name: optimization-operator
description: |
  Operate performance-sensitive AI systems.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Optimization Operator

Monitor latency spikes, token surges, routing errors, and degraded user experience.
