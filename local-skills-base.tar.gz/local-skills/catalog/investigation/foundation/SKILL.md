---
name: investigation-foundation
description: |
  Base investigative analysis principles.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Investigation Foundation

Frame a claim, gather independent evidence, and avoid jumping past what the evidence supports.
