---
name: investigation-operator
description: |
  Operate investigative workflows and manage evidence trails.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Investigation Operator

Track sources, chain of reasoning, and unresolved questions.
