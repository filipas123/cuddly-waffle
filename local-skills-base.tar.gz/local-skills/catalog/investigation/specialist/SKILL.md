---
name: investigation-specialist
description: |
  Advanced anomaly detection and evidentiary analysis.
license: MIT
metadata:
  author: local
  version: "1.0.0"
---

# Investigation Specialist

Use for complex cross-source investigations and lead generation.
