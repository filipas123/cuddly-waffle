---
name: investigation-reviewer
description: |
  Review investigative analysis for evidentiary weakness, overstatement,
  source gaps, and weak reasoning chains.
license: MIT
metadata:
  author: local
  version: "1.1.0"
---

# Investigation Reviewer

Review whether the reasoning chain justifies the stated conclusion.

## Findings to Look For

- anomaly described as proof
- dependence on a single weak source
- mismatched entities, dates, or identifiers
- skipped reasoning steps between evidence and conclusion
- missing explanation of why a discrepancy matters
