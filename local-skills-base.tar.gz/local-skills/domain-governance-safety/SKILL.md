---
name: domain-governance-safety
description: |
  AI governance and policy enforcement skill derived from agent-governance examples in awesome-llm-apps.
  Use when defining guardrails, sandboxing actions, validating tool permissions, designing approval flows,
  or adding auditability and policy enforcement around agent behavior.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# Domain Governance Safety

Use this skill when agent behavior must be constrained and auditable.

## When to Apply

Use this skill when:
- Tool use or automation needs policy boundaries
- Human approval gates are required
- Sensitive operations need allowlists or deny rules
- Audit logging, compliance, or deterministic controls matter

## Core Controls

- filesystem scope
- network allowlists
- action rate limits
- approval-required actions
- tool allow/deny policy
- action audit trail

## Working Style

1. Define the protected assets first.
2. Specify least-privilege policies.
3. Mark which actions are auto-allowed, denied, or approval-gated.
4. Make policy decisions inspectable.
5. Treat prompt-only constraints as insufficient for high-risk actions.
