# Local Skills Base

This workspace now has two layers:

## 1. Canonical Tiered Catalog

Primary skill base:
[catalog](/home/ubuntu/.openclaw/workspace/local-skills/catalog)

Start with:
- [MANIFEST.md](/home/ubuntu/.openclaw/workspace/local-skills/catalog/MANIFEST.md)
- [README.md](/home/ubuntu/.openclaw/workspace/local-skills/catalog/README.md)

The catalog is the source of truth for ongoing expansion.

## 2. Legacy Flat Skills

The top-level skill directories in `local-skills/` remain as seed material and backward references.
They are no longer the preferred structure for future additions.

## Usage

1. Choose the area.
2. Choose the level.
3. Read that `SKILL.md`.
4. Apply it to the task.

## Goal

Provide a broad, reusable local skill base capable of supporting AI/LLM development, software engineering, orchestration, governance, research, architecture, and domain content workflows.
