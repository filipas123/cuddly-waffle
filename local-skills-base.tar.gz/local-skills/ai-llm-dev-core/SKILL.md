---
name: ai-llm-dev-core
description: |
  Core AI/LLM application development skill derived from AI and LLM app examples across awesome-llm-apps.
  Use when building model-backed apps, chat interfaces, memory features, tool use, agent loops,
  evaluation paths, prompt contracts, and end-to-end LLM product behavior.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# AI LLM Dev Core

Use this skill for practical AI/LLM product development.

## When to Apply

Use this skill when:
- Building an LLM-backed feature or application
- Designing chat, memory, tool use, or agent behavior
- Debugging model output quality or product behavior
- Choosing app patterns for LLM integration

## Core Areas

- prompt and instruction design
- structured output
- session and memory handling
- tool invocation design
- retrieval integration
- evaluation and failure analysis
- latency, cost, and context optimization

## Development Rules

1. Start with the product behavior, not the model name.
2. Make inputs and outputs explicit.
3. Test failure modes early.
4. Separate orchestration logic from UI and model provider logic.
5. Add observability before adding complexity.
