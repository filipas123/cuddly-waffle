---
name: llm-apps-rag-builder
description: |
  Retrieval-augmented generation skill derived from RAG tutorials in awesome-llm-apps.
  Use when building or evaluating RAG flows, document ingestion, retrieval strategies, source attribution,
  reasoning over retrieved context, or debugging answer quality in retrieval-backed systems.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# LLM Apps RAG Builder

Use this skill for retrieval-backed assistants and document-grounded answering.

## When to Apply

Use this skill when:
- The user is building or debugging a RAG pipeline
- Retrieved documents, chunks, embeddings, or citations matter
- You need to reason about retrieval quality versus generation quality
- The task involves local or remote knowledge sources

## Core Checks

1. Source ingestion: what enters the index, in what format, and with what chunking.
2. Retrieval: what search method is used and whether the retrieved context is relevant.
3. Grounding: whether the answer matches retrieved evidence.
4. Attribution: whether citations or sources are exposed clearly.
5. Failure modes: hallucination, low recall, noisy chunks, stale docs, duplicate docs.

## Design Guidance

- Keep chunks semantically coherent
- Prefer explicit citations when the user needs trustable output
- Separate retrieval failure from answer-generation failure
- Use evaluation examples instead of vague confidence claims

## Output Requirements

When designing or reviewing a RAG system, provide:
- Architecture summary
- Retrieval path
- Known failure modes
- Recommended improvements
- Test prompts or evaluation cases
