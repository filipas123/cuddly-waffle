---
name: ai-llm-dev-optimization
description: |
  LLM optimization skill derived from optimization tutorials in awesome-llm-apps.
  Use when improving latency, token efficiency, context usage, routing strategy, or balancing output quality,
  cost, and responsiveness in AI systems.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# AI LLM Dev Optimization

Use this skill when the problem is speed, cost, or context pressure.

## When to Apply

Use this skill when:
- Token usage is too high
- Latency is too slow
- Context windows are being wasted
- A routing or model-selection strategy is needed
- The user wants practical optimization, not theoretical tuning

## Optimization Areas

- prompt compression
- context pruning
- routing by task difficulty
- caching opportunities
- streaming and incremental rendering
- retrieval budget control
- model/tool choice by workload

## Rule

Never optimize blind. Identify whether the bottleneck is prompt size, retrieval noise, model choice, orchestration overhead, or UI waiting time first.
