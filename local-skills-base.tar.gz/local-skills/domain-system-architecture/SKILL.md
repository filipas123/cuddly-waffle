---
name: domain-system-architecture
description: |
  Software architecture analysis skill derived from system-architect agent examples in awesome-llm-apps.
  Use when designing systems, choosing architecture patterns, analyzing scalability, security, cost,
  reliability, data design, or implementation roadmaps.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# Domain System Architecture

Use this skill for architecture-level technical decisions.

## When to Apply

Use this skill when:
- The user needs a system design or architecture review
- Tradeoffs between patterns or platforms matter
- Non-functional requirements drive the design
- Security, reliability, and scale need explicit treatment

## Analysis Frame

Cover:
- requirements and constraints
- architecture pattern choice
- data and storage model
- security and compliance needs
- performance and scaling path
- observability and operations
- risks and rollout plan

## Output Requirements

Provide:
- recommended architecture
- reasons for the choice
- major tradeoffs
- implementation phases
- key risks and mitigations
