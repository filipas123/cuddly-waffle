---
name: llm-apps-multi-agent
description: |
  Multi-agent coordination skill derived from advanced multi-agent examples in awesome-llm-apps.
  Use when splitting work across specialized roles, delegating subtasks, reviewing intermediate outputs,
  or designing supervisor-worker patterns with clear boundaries.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# LLM Apps Multi-Agent

Use this skill when a task genuinely benefits from role separation.

## When to Apply

Use this skill when:
- The problem has separable sub-problems with different expertise
- One agent should gather, another should synthesize, and another should review
- The task needs staged outputs and validation between stages
- A supervisor-worker or planner-executor pattern is appropriate

## Coordination Rules

1. Define each agent role in one sentence.
2. Give each role a bounded responsibility.
3. Pass only the minimum context needed to each role.
4. Add a review or verification step before final output.
5. Collapse back to a single-agent flow if orchestration overhead exceeds value.

## Good Role Patterns

- Researcher -> Synthesizer -> Reviewer
- Planner -> Implementer -> Tester
- Retriever -> Analyst -> Writer

## Failure Modes

Watch for:
- duplicated work
- vague responsibilities
- uncontrolled context growth
- circular delegation
- unverified final synthesis

## Output Requirements

When proposing or running multi-agent work, provide:
- role definitions
- execution order
- handoff contract between roles
- validation step before delivery
