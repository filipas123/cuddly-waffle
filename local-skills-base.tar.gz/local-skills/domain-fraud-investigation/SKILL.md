---
name: domain-fraud-investigation
description: |
  Investigative analysis skill derived from fraud-investigation agent examples in awesome-llm-apps.
  Use when cross-checking public records, finding anomalies, validating operational claims against physical
  or documentary evidence, or building evidence-based investigative leads without overstating conclusions.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# Domain Fraud Investigation

Use this skill for anomaly detection and investigative analysis.

## When to Apply

Use this skill when:
- Claims need to be checked against records or observable facts
- Multiple public or internal sources need cross-validation
- The task is investigative rather than transactional
- The result should flag anomalies, not jump to legal conclusions

## Investigation Method

1. Define the claim being tested.
2. Gather independent evidence sources.
3. Compare paperwork, public records, and physical or operational indicators.
4. Flag inconsistencies with explicit reasoning.
5. Use cautious language: anomaly, mismatch, requires review.

## Guardrails

- Do not label something fraud without evidence sufficient for that claim.
- Distinguish lead generation from proof.
- Make the chain of reasoning inspectable.
