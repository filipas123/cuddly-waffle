---
name: ai-llm-dev-evals
description: |
  AI evaluation and diagnostics skill derived from critique, improvement, and failure-diagnostics patterns in awesome-llm-apps.
  Use when defining evals, comparing outputs, diagnosing regressions, setting acceptance criteria,
  or building repeatable tests for model-backed systems.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# AI LLM Dev Evals

Use this skill when AI quality needs to be measured rather than guessed.

## When to Apply

Use this skill when:
- Output quality is inconsistent
- A model or prompt change needs verification
- Failures need categorization and reproduction
- Acceptance criteria for AI behavior are missing

## Evaluation Frame

Define:
- task class
- expected behavior
- scoring criteria
- representative test cases
- failure taxonomy
- regression checks

## Rule

Do not rely on vibe-based evaluation. Convert quality claims into testable examples and explicit pass/fail or scored criteria.
