---
name: domain-finance-advisory
description: |
  Finance and investment analysis skill derived from investment and personal-finance agent examples in awesome-llm-apps.
  Use when comparing financial options, summarizing market context, producing structured financial plans,
  or organizing investment research with explicit assumptions and limits.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# Domain Finance Advisory

Use this skill for structured financial analysis and planning.

## When to Apply

Use this skill when:
- The user wants stock, portfolio, or company comparison
- A personal finance plan or budget is needed
- Market news and fundamentals need synthesis
- Tradeoffs and assumptions should be made explicit

## Core Rules

1. Separate factual data from interpretation.
2. State assumptions and time horizon.
3. Avoid overclaiming certainty.
4. Compare alternatives on consistent criteria.
5. Keep recommendations bounded by the provided information.

## Output Requirements

Provide:
- summary of objective
- comparison table or structured tradeoffs when useful
- risks and unknowns
- next step for validation or decision
