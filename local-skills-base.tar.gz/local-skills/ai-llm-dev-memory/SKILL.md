---
name: ai-llm-dev-memory
description: |
  Memory-oriented AI app development skill derived from memory app tutorials in awesome-llm-apps.
  Use when implementing conversational memory, profile memory, session state, preference retention,
  or deciding what should and should not persist across interactions.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# AI LLM Dev Memory

Use this skill when memory behavior is central to the product.

## When to Apply

Use this skill when:
- A chat app needs persistent or session memory
- User preferences, history, or profile data matter
- You need scoped memory rather than global accumulation
- Memory quality or retrieval is causing product issues

## Core Rules

1. Define memory scope explicitly: turn, session, user, long-term.
2. Store only what improves future behavior.
3. Avoid persisting volatile or sensitive data by default.
4. Make memory retrieval observable and debuggable.
5. Distinguish memory from retrieval index and from raw logs.
