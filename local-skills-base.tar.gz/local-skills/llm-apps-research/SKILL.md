---
name: llm-apps-research
description: |
  Deep research and evidence synthesis skill derived from advanced research agents in awesome-llm-apps.
  Use when the task requires multi-source web research, iterative topic exploration, report writing,
  source comparison, or structured synthesis with citations.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# LLM Apps Research

Use this skill for research-heavy tasks that need more than a quick answer.

## When to Apply

Use this skill when:
- The user asks for deep research on a topic
- Multiple sources need to be compared or synthesized
- A report, brief, memo, or structured findings are needed
- You need iterative research rather than one-shot lookup
- The task benefits from collecting sources, extracting claims, then summarizing

## Working Style

1. Start with a narrow statement of the question.
2. Break the topic into sub-questions.
3. Gather source material from multiple independent sources.
4. Extract concrete facts, dates, claims, and disagreements.
5. Synthesize into a concise answer with explicit uncertainty where needed.
6. Prefer direct source grounding over broad narrative filler.

## Output Requirements

Provide:
- A short framing statement
- Key findings ordered by importance
- Source-backed conclusions
- Open questions or weak-evidence areas
- A recommended next step when useful

## Quality Bar

- Distinguish confirmed facts from interpretation
- Avoid single-source conclusions for contested topics
- Quote or cite only what you can substantiate
- Compress aggressively; do not drown the user in notes
