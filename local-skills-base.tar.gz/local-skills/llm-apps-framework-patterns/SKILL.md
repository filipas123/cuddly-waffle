---
name: llm-apps-framework-patterns
description: |
  Agent framework pattern skill derived from the repo's crash-course materials for OpenAI SDK and Google ADK.
  Use when implementing agents with sessions, guardrails, tool use, structured output, callbacks,
  handoffs, plugins, memory, or orchestration patterns across agent frameworks.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# LLM Apps Framework Patterns

Use this skill for framework-level agent design rather than app-specific glue.

## When to Apply

Use this skill when:
- The task involves agent SDK features like sessions, tools, memory, or handoffs
- You need structured output or validation rules
- Guardrails, callbacks, or plugin-style extension points matter
- The user is comparing or porting patterns between agent frameworks

## Core Topics

- starter agent structure
- tool invocation patterns
- structured output contracts
- context and session management
- memory boundaries
- handoffs and delegation
- observability and tracing
- validation and guardrails

## Design Rules

1. Keep framework-specific code isolated from business logic.
2. Define input and output contracts before adding tools.
3. Prefer explicit validation for structured outputs.
4. Treat memory as scoped state, not a dumping ground.
5. Add observability before scaling orchestration complexity.

## Output Requirements

When advising on framework patterns, provide:
- the pattern being used
- why it fits the task
- the minimal implementation shape
- likely failure modes
- how to test it
