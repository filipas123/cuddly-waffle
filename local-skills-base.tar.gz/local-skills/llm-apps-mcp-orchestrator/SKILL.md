---
name: llm-apps-mcp-orchestrator
description: |
  MCP-oriented orchestration skill derived from multi-MCP agent examples in awesome-llm-apps.
  Use when coordinating multiple tools or services, routing tasks across systems, chaining operations,
  or designing agent workflows that depend on external capabilities.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# LLM Apps MCP Orchestrator

Use this skill when a task spans multiple tools, services, or capability boundaries.

## When to Apply

Use this skill when:
- The user wants one workflow to touch multiple systems
- A task needs tool routing or tool selection logic
- You need to split work between research, code, docs, and service actions
- The problem is better solved by orchestration than a single prompt

## Operating Principles

1. Define the user goal before selecting tools.
2. Minimize tool count; use only the systems required.
3. Sequence actions so each step produces an input for the next.
4. Preserve intermediate outputs that matter for auditability.
5. Fail closed on missing credentials, missing access, or ambiguous side effects.

## Workflow Pattern

- Goal
- Inputs
- Tool or service selection
- Execution order
- Validation of outcome
- Recovery or fallback path

## Quality Bar

- Avoid gratuitous multi-agent complexity
- Prefer deterministic steps for sensitive operations
- Surface auth and permission requirements early
- Keep orchestration understandable enough to debug later
