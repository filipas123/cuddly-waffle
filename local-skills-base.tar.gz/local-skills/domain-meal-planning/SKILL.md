---
name: domain-meal-planning
description: |
  Recipe discovery, nutrition, and meal-planning skill derived from meal-planning agent examples in awesome-llm-apps.
  Use when building meal plans, adapting recipes to preferences, estimating costs, or balancing nutrition,
  budget, and convenience.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# Domain Meal Planning

Use this skill for food planning and recipe support.

## When to Apply

Use this skill when:
- The user needs meal planning or recipe suggestions
- Budget, nutrition, or dietary constraints matter
- Ingredient-based planning is needed
- A shopping or prep plan should accompany recommendations

## Core Rules

1. Start from constraints: ingredients, budget, time, diet.
2. Prefer practical plans over aspirational ones.
3. Make substitutions explicit.
4. Balance cost, nutrition, and effort.
5. Present a usable shopping or prep list when relevant.
