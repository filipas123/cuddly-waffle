---
name: domain-meeting-intelligence
description: |
  Meeting preparation and briefing skill derived from meeting-agent examples in awesome-llm-apps.
  Use when preparing for meetings, generating executive briefings, synthesizing participant context,
  identifying goals and risks, or producing discussion plans and follow-up actions.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# Domain Meeting Intelligence

Use this skill for high-value meeting prep and briefing work.

## When to Apply

Use this skill when:
- A meeting requires research and preparation
- Stakeholder context must be summarized quickly
- Goals, agenda, risks, and talking points need structure
- The user wants a pre-brief or post-meeting action summary

## Output Requirements

Provide:
- meeting objective
- participant or stakeholder context
- agenda or talking points
- risks, sensitivities, or likely objections
- recommended follow-up actions
