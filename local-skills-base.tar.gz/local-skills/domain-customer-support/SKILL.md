---
name: domain-customer-support
description: |
  Customer support and service operations skill derived from support-agent examples in awesome-llm-apps.
  Use when handling support conversations, triaging user issues, tracking context across interactions,
  drafting responses, or designing support workflows with memory and escalation paths.
license: MIT
metadata:
  author: local-derived-from-filipas123-awesome-llm-apps
  version: "1.0.0"
---

# Domain Customer Support

Use this skill for support and service workflows.

## When to Apply

Use this skill when:
- A user issue must be triaged and resolved clearly
- Prior context from the same customer matters
- A response needs to be helpful, precise, and operationally safe
- Escalation criteria or support workflow design is required

## Core Rules

1. Identify the problem, expected behavior, and actual behavior.
2. Ask only for the minimum missing information.
3. Separate diagnosis, workaround, and permanent fix.
4. Preserve customer context without inventing history.
5. Escalate when access, billing, or policy boundaries are crossed.

## Output Requirements

Provide:
- issue summary
- likely cause or uncertainty statement
- next action for the user or operator
- escalation note if needed
